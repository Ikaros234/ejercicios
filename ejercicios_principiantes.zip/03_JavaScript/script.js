function saludar() {
  alert('¡Hola desde JavaScript!');
}