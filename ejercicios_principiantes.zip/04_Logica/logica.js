// Suma de dos números
let a = 5;
let b = 10;
console.log('La suma es:', a + b);